# Machine_Learning_R_Cap8
Seminario donde se explica el capitulo 8 del libro Machine Learning (ML) with R, en el cual se habla del **Market Basquet Analysis**, usando datos de una tienda de alimentos.
Referencia: Machine Learning with R Brett Lantz https://www.amazon.es/Machine-Learning-R-Brett-Lantz/dp/1782162143

Igualmente hay algunos archivos adicionales que fui encontrando durante la preparacion del seminario, y es bueno tener a mano para quienes nos iniciamos en esta aproximacion del ML
