#librerias necesarias
library(class)
library(gmodels)

#======== PASO 2 EXPLORAR LOS DATOS Y PREPARLOS ========
#Importar los datos y ver la tabla
wbcd <- read.csv("~/Documents/INTRODUCION_CIENCIA_DATOS/EXAMPLE_CAP3/wbcd_cvs.csv", 
                 stringsAsFactors = FALSE)
View(wbcd)

#mostrar las variables y tipo de variables
str(wbcd)

#eliminar la primera columna y renombrar la base de datos como wbcd1
wbcd1 <- wbcd[-1]

#mostrar la base de datos
View(wbcd1)

#mostrar el la frecuencia de los elementos del vector diagnosis en la base de datos wbcd1
table(wbcd1$diagnosis)

#cambiar los elementos con nombres
wbcd1$diagnosis<- factor(wbcd$diagnosis, levels = c("B", "M"),
                         labels = c("Benign", "Malignant"))

#ver la frecuencia relativa de los elementos del vector diagnosis
round(prop.table(table(wbcd1$diagnosis)) * 100, digits = 1)

#ver un resumen de los vectores numericos radius_mean y area_mean de la data
summary(wbcd[c("radius_mean", "area_mean")])

#======= TRANSFORMACION DE LOS DATOS. NORMALIZACION DE LOS DATOS NUMERICOS

#escribir una función que normalize segun la funcion min max

normalize_min_max<- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))}

#probar que la funcion normalize_min_max funciona
normalize_min_max(c(1, 2, 3, 4, 5))

#normalizar los valores numericos de la data wbcd1. La funcion 
#lapply () permite aplicar una #funcion especifica a cada 
#elemento de los vectores lista de la data. En nuestro caso 
#aplica #la funcion normalize_min_max a cada elemento numerico 
#de cada vector lista de wbcd1 y el #resultado se escribe 
#como un data frame en wbcd1_n.

wbcd1_n <- as.data.frame(lapply(wbcd1[2:31], normalize_min_max))

#ver la data wbcd1_n
View(wbcd1_n)

#ver un resumen de los vectores numericos radius_mean y area_mean de la data
summary(wbcd1_n[c("radius_mean", "area_mean")])

#para simular este escenario en que tenemo nuevos datos dividimos los 
#datos en dos partes: #el primer conjunto de datos se utilizará para 
#construir el modelo k-NN y el segundo conjunto de datos de 
#prueba que se utiliza para estimar la exactitud predictiva del #modelo. 
#Vamos a utilizar los primeros 469 registros para la formación de datos 
#y los #restantes 100 para simular nuevos pacientes.


#======= PREPARACION DE LOS DATOS: CREACION DE LOS CONJUNTOS DE ENTRENAMIENTOS Y DE PRUEBA ====

#primer conjunto de datos
wbcd_train <- wbcd1_n[1:469, ]
wbcd_test <- wbcd1_n[470:569, ]

#ver las nuevas bases de datos
View(wbcd_train)
View(wbcd_test)

#cuando se construyo las bases de datos anteriores como vienen de la 
#normalizacion se perdio #la variable diagnosis por lo que creamos 
#dos listas con las etiquetas tanto para test como #para train
wbcd_train_labels <- wbcd1[1:469, 1]
wbcd_test_labels <- wbcd1[470:569, 1]

#ver las listas de las etiquetas
View(wbcd_train_labels)
View(wbcd_test_labels)

#================ PASO 3. EL MODELO PARA LOS DATOS ========

wbcd_test_pred <- knn(train = wbcd_train, test = wbcd_test,
                      cl = wbcd_train_labels, k = 21)

#====== PASO 4. EVALUACION DEL RENDIMIENTO DEL MODELO  =========

#creamos una tabulación cruzada que indica el acuerdo entre los dos vectores. 
#Especificación de prop.chisq = FALSO eliminará la innecesaria chi-cuadrado
#Los valores de la salida:

CrossTable(x = wbcd_test_labels, y = wbcd_test_pred,
           prop.chisq=FALSE)


#====== PASO 5. MEJORANDO EL RENDIMIENTO DEL MODELO  =========

#usamos el metodo de normalizacion z-score

wbcd_z <- as.data.frame(scale(wbcd1[2:31]))

#vemos un resumen de los datos normalizados para el vector area_mean
summary(wbcd_z$area_mean)

#primer conjunto de datos ahora con la nueva normalizacion

wbcd_train_z <- wbcd_z[1:469, ]

wbcd_test_z <- wbcd_z[470:569, ]

#creamos dos listas con las etiquetas tanto para test como para train
wbcd_train_labels_z <- wbcd1[1:469, 1]

wbcd_test_labels_z <- wbcd1[470:569, 1]

#creamos el modelo para los datos y aplicamos el algoritmo k-NN
wbcd_test_pred_z <- knn(train = wbcd_train_z, test = wbcd_test_z,
                        cl = wbcd_train_labels_z, k = 21)

#creamos una tabulación cruzada que indica el acuerdo entre los dos vectores. 
#Especificación de prop.chisq = FALSO eliminará la innecesaria chi-cuadrado
#Los valores de la salida:

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z,
           prop.chisq = FALSE)

#====== PROBANDO VALORES ALTERNATIVOS DE K =========

#====================== K=1 =================================
wbcd_test_pred_z1 <- knn(train = wbcd_train_z, test = wbcd_test_z,
                        cl = wbcd_train_labels_z, k = 1)

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z1,
           prop.chisq = FALSE)
#==============================================================


#====================== K=5 =================================
wbcd_test_pred_z5 <- knn(train = wbcd_train_z, test = wbcd_test_z,
                         cl = wbcd_train_labels_z, k = 5)

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z5,
           prop.chisq = FALSE)
#==============================================================

#====================== K=11 =================================
wbcd_test_pred_z11 <- knn(train = wbcd_train_z, test = wbcd_test_z,
                         cl = wbcd_train_labels_z, k = 11)

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z11,
           prop.chisq = FALSE)
#==============================================================

#====================== K=15 =================================
wbcd_test_pred_z15 <- knn(train = wbcd_train_z, test = wbcd_test_z,
                         cl = wbcd_train_labels_z, k = 15)

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z15,
           prop.chisq = FALSE)
#==============================================================

#====================== K=27 =================================
wbcd_test_pred_z27 <- knn(train = wbcd_train_z, test = wbcd_test_z,
                         cl = wbcd_train_labels_z, k = 27)

CrossTable(x = wbcd_test_labels_z, y = wbcd_test_pred_z27,
           prop.chisq = FALSE)
#==============================================================